import Swal from 'sweetalert2/src/sweetalert2.js'

Swal.fire()
